wget http://downloads.sourceforge.net/project/opencvlibrary/opencv-unix/2.4.8/opencv-2.4.8.zip?r=http%3A%2F%2Fopencv.org%2Fdownloads.html&ts=1390248020&use_mirror=kent
