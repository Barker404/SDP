BGR_COMMON = {
    'red': (0, 0, 255),
    'green': (0, 255, 0),
    'blue': (255, 154, 66),
    'black': (0, 0, 0),
    'white': (255, 255, 255),
    'yellow': (0, 255, 255),
    'bright_green': (0, 255, 102),
    'orange': (66, 186, 255)
}